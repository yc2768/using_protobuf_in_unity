﻿using System;
using System.Collections.Generic;
using System.Text;
using ProtoBuf;

namespace SaveDate
{
    [ProtoContract]
    public class Item
    {
        [ProtoMember(1)]
        public string name;
        [ProtoMember(2)]
        public int price;

        public Item(string name, int price)
        {
            this.name=name;
            this.price = price;
        }
    }

    [ProtoContract]
    public class Troply
    {
        [ProtoMember(1)]
        public string name;
        [ProtoMember(2)]
        public string description;

        public Troply()
        {
            this.name = "Troply";
            this.description = "description";
        }
        public Troply(string name, string description)
        {
            this.name = name;
            this.description = description;
        }
    }
}
