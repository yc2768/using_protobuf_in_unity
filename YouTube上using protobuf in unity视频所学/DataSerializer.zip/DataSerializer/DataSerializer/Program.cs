﻿using System;
using System.Collections.Generic;
using System.Text;
using SaveDate;
using ProtoBuf.Meta;
namespace DataSerializer
{
    class Program
    {
        static void Main(string[] args)
        {
            var model = TypeModel.Create();

            model.Add(typeof(Item), true);
            model.Add(typeof(Troply), true);

            model.AllowParseableTypes = true;
            model.AutoAddMissingTypes = true;

            model.Compile("DataSeriallizer","DataSerializer.dll");

        }
    }
}
